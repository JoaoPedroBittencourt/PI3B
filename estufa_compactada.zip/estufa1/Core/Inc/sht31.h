#ifndef __SHT31_H
#define __SHT31_H

#include "stm32f1xx_hal.h"

// Endereço I2C do SHT31 (7-bit, com ADDR pino LOW - 0x44)
#define SHT31_ADDR_7BIT (0x44)

// Comando para Leitura de Alta Repetibilidade (High Repeatability)
#define SHT31_CMD_MEAS_HIGH_REP_NO_STRETCH 0x2400

typedef struct {
    float temperature; // Temperatura em Celsius
    float humidity;    // Umidade relativa (%)
} SHT31_Data_t;

// Declara o handler I2C, assumindo que você usou o I2C1
extern I2C_HandleTypeDef hi2c1;

// Função para ler dados do SHT31
uint8_t SHT31_Read_Data(SHT31_Data_t *data);

#endif /* __SHT31_H */
