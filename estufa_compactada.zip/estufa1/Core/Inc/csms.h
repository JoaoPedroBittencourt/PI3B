#ifndef __CSMS_H
#define __CSMS_H

#include "stm32f1xx_hal.h"

// Declara o handler ADC1 (definido em adc.c)
extern ADC_HandleTypeDef hadc1;

// Função para ler o valor bruto do ADC
uint16_t CSMS_Read_Raw(void);

// Função para ler e converter para porcentagem de umidade
float CSMS_Read_Percent(void);

#endif /* __CSMS_H */
