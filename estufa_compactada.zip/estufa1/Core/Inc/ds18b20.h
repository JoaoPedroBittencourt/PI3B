#ifndef INC_DS18B20_H_
#define INC_DS18B20_H_

#include "stm32f1xx_hal.h"

// Define o pino onde o sensor DS18B20 está conectado
// **Certifique-se de que estes correspondem ao seu CubeMX**
#define DS18B20_PORT GPIOA
#define DS18B20_PIN  GPIO_PIN_7

// Comandos ROM (para endereçamento)
#define READ_ROM         0x33
#define MATCH_ROM        0x55
#define SKIP_ROM         0xCC
#define SEARCH_ROM       0xF0

// Comandos de Funções (para operações)
#define CONVERT_T        0x44 // Inicia a conversão de temperatura
#define READ_SCRATCHPAD  0xBE // Lê os registradores de temperatura
#define WRITE_SCRATCHPAD 0x4E // Escreve nos registradores de alarme

// --- Funções de Implementação do Protocolo One-Wire ---
uint8_t DS18B20_Start(void);
void DS18B20_Write(uint8_t data);
uint8_t DS18B20_Read(void);

// --- Funções de Alto Nível do DS18B20 ---
float DS18B20_ReadTemp(void);

#endif /* INC_DS18B20_H_ */
