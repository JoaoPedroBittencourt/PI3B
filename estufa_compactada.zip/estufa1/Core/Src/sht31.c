#include "sht31.h"
#include "main.h" // Inclui main.h para ter acesso a hi2c1

// Definição da variável externa (garante que o linker a encontre)
extern I2C_HandleTypeDef hi2c1;

/**
 * @brief Envia um comando de 16-bit para o SHT31.
 */
static void SHT31_Send_Cmd(uint16_t command) {
    uint8_t cmd_buffer[2];
    cmd_buffer[0] = (uint8_t)(command >> 8);
    cmd_buffer[1] = (uint8_t)(command & 0xFF);
    // Endereço I2C de 8-bit é 0x44 << 1 = 0x88
    HAL_I2C_Master_Transmit(&hi2c1, SHT31_ADDR_7BIT << 1, cmd_buffer, 2, 200);
}

/**
 * @brief Lê a temperatura e umidade do SHT31.
 * @param data Ponteiro para a struct onde os dados serão armazenados.
 * @retval 1 em caso de sucesso, 0 em caso de falha.
 */
uint8_t SHT31_Read_Data(SHT31_Data_t *data) {
    uint8_t rx_buffer[6];
    uint16_t ST, SRH;

    // 1. Envia comando de medição (High Repeatability, sem clock stretching)
    SHT31_Send_Cmd(SHT31_CMD_MEAS_HIGH_REP_NO_STRETCH);

    // Espera o tempo de conversão (mínimo 15ms)
    HAL_Delay(50);

    // 2. Lê 6 bytes (Temp MSB, LSB, CRC, Hum MSB, LSB, CRC)
    if (HAL_I2C_Master_Receive(&hi2c1, SHT31_ADDR_7BIT << 1, rx_buffer, 6, 200) != HAL_OK) {
        data->temperature = -999.0f; // Marca como erro
        data->humidity = -999.0f;
        return 0;
    }

    // Processa os dados (CRC omitido para simplificação)
    ST = (uint16_t)(rx_buffer[0] << 8) | rx_buffer[1];
    SRH = (uint16_t)(rx_buffer[3] << 8) | rx_buffer[4];

    // Fórmulas de conversão:
    // Temperatura: T = -45 + 175 * (ST / 65535)
    data->temperature = -45.0f + 175.0f * ((float)ST / 65535.0f);

    // Umidade: RH = 100 * (SRH / 65535)
    data->humidity = 100.0f * ((float)SRH / 65535.0f);

    return 1; // Sucesso
}
