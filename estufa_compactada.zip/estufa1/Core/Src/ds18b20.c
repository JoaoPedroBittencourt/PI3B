#include "ds18b20.h"
#include "main.h" // Para ter acesso ao handler do TIM3 (htim3)

// Variável externa do TIM3
extern TIM_HandleTypeDef htim3;

// --- Funções de Atraso e Configuração de Pino ---

// Função de atraso em microsegundos usando o TIM3
void DWT_Delay_us(uint32_t us)
{
    // Reinicia o contador e o overflow flag do TIM3
    __HAL_TIM_SET_COUNTER(&htim3, 0);

    // Espera até que o contador atinja o valor desejado (us)
    // O contador incrementa a cada 1us, graças ao Prescaler (71)
    while (__HAL_TIM_GET_COUNTER(&htim3) < us);
}

// Configura o pino One-Wire como Entrada
static void Set_Pin_Input(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS18B20_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP; // O sensor usa um pull-up externo/interno
    HAL_GPIO_Init(DS18B20_PORT, &GPIO_InitStruct);
}

// Configura o pino One-Wire como Saída (Push-Pull, Low)
static void Set_Pin_Output(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS18B20_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DS18B20_PORT, &GPIO_InitStruct);
}

// --- Funções de Comunicação One-Wire ---

// 1. Inicializa a comunicação One-Wire
uint8_t DS18B20_Start(void)
{
    uint8_t Response = 0;

    // 1. Reset Pulse (>= 480us)
    Set_Pin_Output();       // Configura como saída
    HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_RESET); // Pino LOW (Aterrado)
    DWT_Delay_us(480);

    // 2. Espera pela Presença (max 60us)
    Set_Pin_Input();        // Configura como entrada (O pino sobe via pull-up)
    DWT_Delay_us(60);

    // 3. Verifica o Sensor (Presença Pulse)
    if (HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN) == GPIO_PIN_RESET)
    {
        Response = 1; // Sensor Presente (Pino LOW)
    }
    else
    {
        Response = 0; // Sensor Ausente (Pino HIGH)
    }

    // 4. Aguarda o final do slot de presença (min 480us - tempo já decorrido)
    DWT_Delay_us(420); // 480 - 60 = 420

    return Response;
}

// 2. Escreve 1 Byte de dados
void DS18B20_Write(uint8_t data)
{
    Set_Pin_Output(); // Configura como saída

    for (int i = 0; i < 8; i++)
    {
        if ((data & (1 << i))) // Se o bit for 1 (Escrita de '1')
        {
            // PULL DOWN por 2us (Início do slot)
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_RESET); // LOW
            DWT_Delay_us(2);

            // PULL UP por 60us (Final do slot)
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_SET); // HIGH
            DWT_Delay_us(60);
        }
        else // Se o bit for 0 (Escrita de '0')
        {
            // PULL DOWN por 60us (Início do slot)
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_RESET); // LOW
            DWT_Delay_us(60);

            // PULL UP por 2us (Final do slot)
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_SET); // HIGH
            DWT_Delay_us(2);
        }
    }
}

// 3. Lê 1 Byte de dados
uint8_t DS18B20_Read(void)
{
    uint8_t data = 0;
    Set_Pin_Input(); // Configura como entrada para receber dados

    for (int i = 0; i < 8; i++)
    {
        // PULL DOWN por 2us (Inicia o slot de leitura)
        Set_Pin_Output();
        HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, GPIO_PIN_RESET); // LOW
        DWT_Delay_us(2);

        // PULL UP (Libera o sensor para responder)
        Set_Pin_Input();

        // Espera para amostrar o pino (Leitura após 15us)
        DWT_Delay_us(10); // 10us para garantir o tempo

        if (HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN) == GPIO_PIN_SET)
        {
            data |= (1 << i); // Recebeu um '1'
        }

        // Espera pelo resto do slot de leitura (aprox 60us no total)
        DWT_Delay_us(50); // 10us + 50us = 60us
    }

    return data;
}

// --- Função de Leitura da Temperatura ---

float DS18B20_ReadTemp(void)
{
    uint8_t temp_msb, temp_lsb;
    int16_t temp_int;
    float temp_float;

    if (DS18B20_Start()) // 1. Reset e verificação de presença
    {
        DS18B20_Write(SKIP_ROM);   // 2. Pula a verificação de endereço (para um único sensor)
        DS18B20_Write(CONVERT_T);  // 3. Manda converter a temperatura (44h)

        // Aguarda a conversão (pode levar até 750ms para 12-bit)
        // Usaremos o delay do HAL aqui, já que é um tempo longo
        HAL_Delay(800);

        if (DS18B20_Start()) // 4. Reset e verificação de presença (2a vez)
        {
            DS18B20_Write(SKIP_ROM);        // 5. Pula a verificação de endereço
            DS18B20_Write(READ_SCRATCHPAD); // 6. Manda ler o scratchpad (BEh)

            // 7. Lê os 9 bytes do scratchpad
            temp_lsb = DS18B20_Read(); // Byte 0 (LSB - menos significativo)
            temp_msb = DS18B20_Read(); // Byte 1 (MSB - mais significativo)
            // Os demais bytes são ignorados, mas seriam lidos se fossem necessários
        }
    }

    // Converte os bytes lidos para um valor de temperatura
    // A temperatura é armazenada como um inteiro de 16 bits (complemento de dois)
    temp_int = (temp_msb << 8) | temp_lsb;

    // Divide por 16.0 para obter a temperatura em Celsius
    // (Resolução de 12-bit, onde 1 bit = 0.0625 °C)
    temp_float = (float)temp_int / 16.0f;

    return temp_float;
}
