#include "csms.h"
#include "main.h" // Inclui main.h para ter acesso a hadc1

// Definição da variável externa (garante que o linker a encontre)
extern ADC_HandleTypeDef hadc1;

// Calibração: estes valores dependem do seu sensor e do ambiente.
// Você deve medi-los e ajustá-los.
#define CSMS_AIR_VALUE    3000 // Valor bruto do ADC quando o sensor está SECO (no ar)
#define CSMS_WATER_VALUE  1000 // Valor bruto do ADC quando o sensor está MOLHADO (na água)

/**
 * @brief Lê o valor bruto do ADC do CSMS (Canal PA0).
 * @retval Valor de 16-bit do ADC (0 a 4095).
 */
uint16_t CSMS_Read_Raw(void) {
    uint16_t adc_value;

    // Inicia a conversão regular do ADC
    HAL_ADC_Start(&hadc1);

    // Espera a conversão terminar
    if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK) {
        // Obtém o valor lido
        adc_value = HAL_ADC_GetValue(&hadc1);
    } else {
        // Em caso de timeout ou erro, retorna 0
        adc_value = 0;
    }

    // Para a conversão
    HAL_ADC_Stop(&hadc1);

    return adc_value;
}

/**
 * @brief Converte o valor bruto do ADC para porcentagem de umidade.
 * @retval Porcentagem de umidade (0.0 a 100.0).
 */
float CSMS_Read_Percent(void) {
    uint16_t raw_value = CSMS_Read_Raw();
    float percent;

    // Mapeia o valor bruto entre o ponto seco e o ponto molhado
    // Mapeamento: percent = 100 * (Valor_Seco - Valor_Lido) / (Valor_Seco - Valor_Molhado)

    // Evita divisão por zero
    if (CSMS_AIR_VALUE == CSMS_WATER_VALUE) {
        return 0.0f;
    }

    // Calcula o percentual: 0% = Seco (valor alto), 100% = Molhado (valor baixo)
    percent = (float)(CSMS_AIR_VALUE - raw_value) / (float)(CSMS_AIR_VALUE - CSMS_WATER_VALUE);

    // Limita o valor entre 0% e 100%
    if (percent < 0.0f) {
        percent = 0.0f;
    } else if (percent > 1.0f) {
        percent = 1.0f;
    }

    return percent * 100.0f;
}
